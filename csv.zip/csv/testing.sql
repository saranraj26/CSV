
--
-- Database: `testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  
  `student_name` varchar(250) NOT NULL,
  `student_phone` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
  
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

ALTER TABLE `tbl_student`
ADD PRIMARY KEY (`student_phone`);